# AndroidDevelopers-2021
GIT Commands to be used by all

A) Install GIT and GITFlow on your system

B) Follow instructions to push your work on the repository. 
https://blog.scottlowe.org/2015/01/27/using-fork-branch-git-workflow/
  
C)Create new branch in your git account forked repository according to your group and email id
 Like if you belong to Group A and your email is demo@gmail.com
 then your branch would be a-group-demo.
 
D) After finishing your task you have to push changes in this repository.

E) Do also add snapshot or video of your work in the current directory.


Before starting your work kindly take latest pull by using command
** git pull upstream main **

You would get latest changes in your branch and you can start workiing on your given task. When you will finish your given task then create pull request from your forked repository in your git account.
  
*** All of you have to work on the blank project given here **
When you all get blank project just change the SDK path given at local.properties to your own SDK path.

If you are having issues no worry keep working on your forked repository , and then let me know your repository name where you have completed the task.


**Gold Badge** 
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
**Bronze Badge**                                          
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
**Silver Badge**
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.



